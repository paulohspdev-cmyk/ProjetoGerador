import json
import math
import os
import sqlite3
import subprocess
import threading
import time
from datetime import datetime, timedelta, timezone

from .binding_store import load_runtime_bindings
from .config import (
    BRIDGE_STATUS_FILE,
    RAPID_CACHE_TTL,
    RAPID_COMM_CONFIG,
    RAPID_READER_DLL,
)
from .controller_library import pack_for_model
from . import db

_cache = {"at": 0.0, "channels": {}, "error": "", "requested": set()}
_cache_lock = threading.Lock()

_COMAP_UNDEFINED = {-32768.0, 32768.0, -2147483648.0, 2147483648.0}
_DSE_16_UNDEFINED = {float(value) for value in range(0xFFF8, 0x10000)} | {
    float(value) for value in range(0x7FF8, 0x8000)
}
_DSE_32_UNDEFINED = {float(value) for value in range(0xFFFFFFF8, 0x100000000)} | {
    float(value) for value in range(0x7FFFFFF8, 0x80000000)
}
_DSE_STATUS_KEYS = {"controller_mode_raw", "controller_status_flags_raw"}

_COMAP_SENTINEL_KEYS = {
    "fuel_rate",
    "coolant_temperature",
    "intake_temperature",
    "oil_pressure",
    "intake_pressure",
    "engine_load",
    "power_kw",
    "power_kvar",
    "power_kva",
    "power_factor",
    "mains_power_kw",
    "mains_power_kvar",
    "mains_power_factor",
    "battery_voltage",
    "alternator_voltage",
    "fuel_level",
    "maintenance_hours",
}
RAPID_READER_TIMEOUT = max(1.0, float(os.environ.get("RC_RAPID_READER_TIMEOUT", "4")))
BRIDGE_STATUS_STALE_SECONDS = max(
    5.0,
    float(os.environ.get("RC_BRIDGE_STATUS_STALE_SECONDS", "15")),
)
_CONTROLLER_HEALTH_KEYS = (
    "rpm",
    "battery_voltage",
    "controller_mode_raw",
    "engine_state_raw",
)

# Somente estas métricas podem sobreviver à perda de leitura no overlay do card.
# O histórico completo continua pertencendo ao Rapid SCADA.
_LAST_KNOWN_CARD_METRICS = {"fuel_level", "maintenance_hours", "run_hours"}


def load_bindings():
    """Bindings ausentes significam VM ainda não provisionada; corrupção é erro real."""
    return load_runtime_bindings()


def _binding_identity_matches(generator, item):
    return (
        str(item.get("controller_type", "")).upper()
        == str(generator.get("controller_type", "")).upper()
        and str(item.get("controller_model", "")).strip().lower()
        == str(generator.get("controller_model", "")).strip().lower()
        and str(item.get("transport") or "") == str(generator.get("transport") or "")
        and int(item.get("listen_port") or 0) == int(generator.get("listen_port") or 0)
        and int(item.get("modbus_unit") or 0) == int(generator.get("modbus_unit") or 0)
        and (
            not generator.get("rapid_device_num")
            or int(item.get("rapid_device_num") or 0)
            == int(generator.get("rapid_device_num") or 0)
        )
    )


def binding_for(generator, bindings):
    """Resolve binding por generator_id e só usa fallback para legado sem dono.

    Um binding já associado a outro generator_id nunca pode ser adotado apenas
    porque porta/Unit/Device coincidem.
    """
    generator_id = str(generator.get("id") or "")
    if generator_id:
        exact = next(
            (
                item
                for item in bindings
                if str(item.get("generator_id") or "") == generator_id
            ),
            None,
        )
        if exact is not None:
            return exact if _binding_identity_matches(generator, exact) else None

    for item in bindings:
        if item.get("generator_id"):
            continue
        if _binding_identity_matches(generator, item):
            return item
    return None


def _reader_ready():
    if not RAPID_READER_DLL.exists():
        return f"Leitor do motor de telemetria não instalado: {RAPID_READER_DLL}"
    if not RAPID_COMM_CONFIG.exists():
        return f"Configuração do motor de telemetria não encontrada: {RAPID_COMM_CONFIG}"
    return ""


def _is_undefined_raw(generator, key, raw_value):
    """Filtra sentinelas Modbus sem transformar N/D em grandezas físicas.

    ComAp usa sentinelas próprias. DSE GenComm reserva os oito valores no
    topo das faixas signed/unsigned de 16 e 32 bits para estados especiais
    de instrumentação (unimplemented, range, transducer fault, bad data,
    entradas digitais e reserved). Campos de status da página 3 não usam
    esse contrato e ficam fora do filtro.
    """
    controller_type = str(generator.get("controller_type") or "").strip().upper()
    try:
        value = float(raw_value)
    except (TypeError, ValueError, OverflowError):
        return False

    if controller_type == "COMAP":
        return key in _COMAP_SENTINEL_KEYS and value in _COMAP_UNDEFINED
    if controller_type == "DSE":
        return key not in _DSE_STATUS_KEYS and (
            value in _DSE_16_UNDEFINED or value in _DSE_32_UNDEFINED
        )
    return False


def _cache_hit(nums, now):
    if now - _cache["at"] >= RAPID_CACHE_TTL:
        return False
    requested = set(_cache.get("requested") or set())
    if _cache.get("error"):
        return set(nums).issubset(requested)
    return all(n in _cache["channels"] for n in nums)


def _cache_result(nums, channels, error=""):
    _cache["at"] = time.monotonic()
    _cache["channels"] = dict(channels)
    _cache["error"] = str(error or "")
    _cache["requested"] = set(nums)


def read_channels(channel_nums):
    """Lê canais em lote, com cache positivo e negativo contra stampede .NET."""
    nums = sorted({int(n) for n in channel_nums})
    if not nums:
        return {}, ""

    now = time.monotonic()
    if _cache_hit(nums, now):
        return {n: _cache["channels"][n] for n in nums if n in _cache["channels"]}, _cache["error"]

    with _cache_lock:
        now = time.monotonic()
        if _cache_hit(nums, now):
            return {n: _cache["channels"][n] for n in nums if n in _cache["channels"]}, _cache["error"]

        ready_error = _reader_ready()
        if ready_error:
            _cache_result(nums, {}, ready_error)
            return {}, ready_error

        cmd = [
            "dotnet",
            str(RAPID_READER_DLL),
            str(RAPID_COMM_CONFIG),
            "current",
            *[str(n) for n in nums],
        ]
        try:
            proc = subprocess.run(
                cmd,
                capture_output=True,
                text=True,
                timeout=RAPID_READER_TIMEOUT,
                check=False,
            )
        except Exception as exc:
            error = f"Falha ao consultar motor de telemetria: {exc}"
            _cache_result(nums, {}, error)
            return {}, error

        if proc.returncode != 0:
            detail = (proc.stderr or proc.stdout or "erro desconhecido").strip()
            error = f"Motor de telemetria: {detail[:300]}"
            _cache_result(nums, {}, error)
            return {}, error

        try:
            payload = json.loads(proc.stdout)
            channels = {
                int(item["cnl"]): {
                    "val": item.get("val", 0),
                    "stat": int(item.get("stat", 0)),
                    "defined": bool(item.get("defined", False)),
                }
                for item in payload.get("channels", [])
            }
        except Exception as exc:
            error = f"Resposta inválida do motor de telemetria: {exc}"
            _cache_result(nums, {}, error)
            return {}, error

        _cache_result(nums, channels, "")
        return channels, ""


def _load_bridge_status():
    try:
        payload = json.loads(BRIDGE_STATUS_FILE.read_text(encoding="utf-8"))
        if not isinstance(payload, dict):
            return {}
        return payload
    except Exception:
        return {}


def _transport_health(generator, bridge_status):
    transport = str(generator.get("transport") or "reverse_tcp")
    base = {
        "transport": "unknown",
        "controller": "unknown",
        "telemetry": "unknown",
        "bridgeStatusFresh": None,
        "bridgeUpdatedAt": None,
        "portLastRxAt": None,
        "portLastTxAt": None,
        "portTimeouts": None,
        "portErrors": None,
    }
    if transport != "reverse_tcp":
        return base

    updated_at = int(bridge_status.get("updatedAt") or 0)
    fresh = bool(updated_at and time.time() - updated_at <= BRIDGE_STATUS_STALE_SECONDS)
    base["bridgeStatusFresh"] = fresh
    base["bridgeUpdatedAt"] = updated_at or None
    if not fresh:
        return base

    port = int(generator.get("listen_port") or 0)
    item = next(
        (
            row
            for row in bridge_status.get("ports", [])
            if int(row.get("remotePort") or 0) == port
        ),
        None,
    )
    if not item:
        base["transport"] = "disconnected"
        return base

    base.update(
        {
            "transport": "connected" if bool(item.get("connected")) else "disconnected",
            "portLastRxAt": item.get("lastRxAt"),
            "portLastTxAt": item.get("lastTxAt"),
            "portTimeouts": int(item.get("timeouts") or 0),
            "portErrors": int(item.get("errors") or 0),
        }
    )
    return base


def _downsample_points(points: list[dict], max_points: int = 2000) -> list[dict]:
    max_points = max(2, int(max_points))
    if len(points) <= max_points:
        return points
    last = len(points) - 1
    indexes = [round(i * last / (max_points - 1)) for i in range(max_points)]
    return [points[index] for index in indexes]


def trend_for_generator(generator, metric, hours=24, archive_bit=1):
    hours = max(1, min(int(hours), 24 * 31))
    archive_bit = int(archive_bit)
    if archive_bit not in {1, 2, 3}:
        raise ValueError("ArchiveBit permitido: 1 minuto, 2 horário ou 3 diário")

    binding = binding_for(generator, load_bindings())
    if not binding:
        raise ValueError("Gerador sem vínculo no motor de telemetria")
    channel_cfg = (binding.get("channels") or {}).get(metric)
    if not channel_cfg or "cnl" not in channel_cfg:
        available = ", ".join(sorted((binding.get("channels") or {}).keys()))
        raise ValueError(f"Métrica não disponível neste Controller Pack. Disponíveis: {available}")

    ready_error = _reader_ready()
    if ready_error:
        raise ConnectionError(ready_error)

    cnl = int(channel_cfg["cnl"])
    scale = float(channel_cfg.get("scale", 1.0))
    end = datetime.now(timezone.utc)
    start = end - timedelta(hours=hours)
    cmd = [
        "dotnet",
        str(RAPID_READER_DLL),
        str(RAPID_COMM_CONFIG),
        "trend",
        str(archive_bit),
        str(cnl),
        start.isoformat(),
        end.isoformat(),
    ]
    try:
        proc = subprocess.run(cmd, capture_output=True, text=True, timeout=15, check=False)
    except subprocess.TimeoutExpired as exc:
        raise TimeoutError("Timeout ao consultar histórico do motor de telemetria") from exc
    except Exception as exc:
        raise ConnectionError(f"Falha ao consultar histórico do motor de telemetria: {exc}") from exc

    if proc.returncode != 0:
        detail = (proc.stderr or proc.stdout or "erro desconhecido").strip()
        raise ConnectionError(f"Motor de telemetria: {detail[:500]}")

    try:
        payload = json.loads(proc.stdout)
    except Exception as exc:
        raise ConnectionError(f"Resposta inválida do histórico do motor de telemetria: {exc}") from exc

    points = []
    for item in payload.get("points", []):
        if not item.get("defined"):
            continue
        raw_value = item.get("val", 0)
        if _is_undefined_raw(generator, metric, raw_value):
            continue
        try:
            value = float(raw_value) * scale
        except (TypeError, ValueError, OverflowError):
            continue
        if not math.isfinite(value):
            continue
        points.append(
            {
                "timestamp": item.get("timestamp"),
                "value": round(value, 4),
                "stat": int(item.get("stat", 0)),
            }
        )

    # Evenly sample the complete time window and always preserve both ends.
    # The old integer-step + truncation could discard hours from the tail.
    points = _downsample_points(points, 2000)

    return {
        "generatorId": generator["id"],
        "tag": generator["tag"],
        "metric": metric,
        "cnl": cnl,
        "scale": scale,
        "archiveBit": archive_bit,
        "start": start.isoformat(),
        "end": end.isoformat(),
        "points": points,
    }


def available_metrics(generator):
    binding = binding_for(generator, load_bindings())
    if not binding:
        return []
    return [
        {
            "key": key,
            "cnl": int(cfg["cnl"]),
            "scale": float(cfg.get("scale", 1.0)),
        }
        for key, cfg in (binding.get("channels") or {}).items()
        if "cnl" in cfg
    ]


def _mode(generator, values):
    if "controller_mode_raw" not in values:
        return "OFF"
    raw = values.get("controller_mode_raw")
    vendor = str(generator.get("controller_type") or "").strip().upper()
    if vendor == "DSE":
        # GenComm control modes: 0 Stop, 1 Auto, 2 Manual, 3 Test on load,
        # 4 Auto with manual restore, 5 User config, 6 Test off load, 7 Off.
        return {
            0: "OFF",
            1: "AUTO",
            2: "MANUAL",
            3: "TESTE",
            4: "AUTO",
            5: "CONFIG",
            6: "TESTE",
            7: "OFF",
        }.get(raw, "N/D")
    return {0: "OFF", 1: "MANUAL", 2: "AUTO", 3: "TESTE"}.get(raw, "N/D")


def _pack(generator):
    model = str(generator.get("controller_model") or "").strip()
    return pack_for_model(model) if model else None


def _metric_units(generator, configured: list[str]) -> dict[str, str]:
    pack = _pack(generator)
    if not pack:
        return {}
    allowed = set(configured)
    units = dict(pack.get("metricUnits") or {})
    for spec in (pack.get("rapid") or {}).get("channels") or []:
        key = str(spec.get("key") or "")
        unit = str(spec.get("unit") or "")
        if key and unit:
            units.setdefault(key, unit)
    return {str(key): str(unit) for key, unit in units.items() if key in allowed and str(unit)}


def _metric_limits(generator) -> dict:
    pack = _pack(generator)
    limits = (pack or {}).get("metricLimits") or {}
    return dict(limits) if isinstance(limits, dict) else {}


def _metric_value_in_documented_range(generator, key: str, value: float) -> bool:
    """Reject values outside explicit physical bounds from the controller export.

    These are validity bounds for the mapped register, not tank capacity or
    protection setpoints.
    """
    pack = _pack(generator)
    registers = ((pack or {}).get("mapping") or {}).get("registers") or {}
    spec = registers.get(key) if isinstance(registers, dict) else None
    if not isinstance(spec, dict):
        return True
    minimum = spec.get("validMin")
    maximum = spec.get("validMax")
    if minimum is not None and value < float(minimum):
        return False
    if maximum is not None and value > float(maximum):
        return False
    return True


def _effective_capabilities(generator, status: str, binding_present: bool) -> dict[str, bool]:
    pack = _pack(generator)
    declared = (pack or {}).get("capabilities") or {}
    production_pack = bool(pack and pack.get("lifecycle") == "production")
    field_validated = bool(production_pack and pack.get("status") == "field_validated")
    online = status == "online"
    commands = dict((pack or {}).get("commands") or {})

    result = {
        "telemetry": bool(production_pack and binding_present and declared.get("telemetry")),
    }
    for action in (
        "start",
        "stop",
        "auto",
        "manual",
        "test",
        "mcb_open",
        "mcb_close",
        "gcb_open",
        "gcb_close",
        "paralleling",
    ):
        result[action] = bool(
            field_validated
            and online
            and binding_present
            and declared.get(action)
            and isinstance(commands.get(action), dict)
        )
    return result


def _derive_breaker_feedback(values):
    """Deriva feedbacks apenas para estados agregados semanticamente inequívocos."""
    raw = values.get("breaker_state_raw")
    mapping = {
        1: (False, False),
        2: (False, True),
        3: (True, False),
        4: (True, True),
        10: (False, True),
        11: (True, True),
    }
    if raw not in mapping:
        return []
    mcb, gcb = mapping[raw]
    values["mcb_closed"] = 1 if mcb else 0
    values["gcb_closed"] = 1 if gcb else 0
    return ["mcb_closed", "gcb_closed"]


def _derive_dse_status(generator, values):
    """Deriva apenas estados DSE inequívocos do bitfield GenComm page 3/offset 6.

    O bit de telemetry alarm (0x0200) não representa necessariamente um alarme
    de processo. Warning, electrical trip, shutdown e control-unit failure são
    tratados como condição ativa. A contagem exata exige page 154; portanto só
    materializamos alarm_count=0 quando o bitfield garante ausência desses estados.
    """
    if str(generator.get("controller_type") or "").strip().upper() != "DSE":
        return []
    raw = values.get("controller_status_flags_raw")
    if raw is None:
        return []
    try:
        flags = int(raw)
    except (TypeError, ValueError, OverflowError):
        return []
    active = bool(flags & 0x3C00)  # warning, electrical trip, shutdown, unit failure
    values["alarm_active"] = 1 if active else 0
    derived = ["alarm_active"]
    if not active:
        values["alarm_count"] = 0
        derived.append("alarm_count")
    return derived


def _has_controller_health(values, configured):
    preferred = [key for key in _CONTROLLER_HEALTH_KEYS if key in set(configured)]
    if preferred:
        return any(key in values for key in preferred)
    return bool(values)


def _frontend_generator(
    generator,
    values,
    status,
    error="",
    defined=None,
    configured_metrics=None,
    binding_present=False,
    health=None,
    telemetry_at=None,
    telemetry_stale=False,
    stale_metrics=None,
):
    enabled = bool(generator.get("enabled"))
    online = status == "online"
    warning = status in {"fault", "connected", "partial"}
    defined_metrics = sorted(set(defined or []))
    configured_metrics = sorted(set(configured_metrics or []))
    stale_metrics = sorted(set(stale_metrics or []))
    units = _metric_units(generator, configured_metrics)
    metric_states = {
        key: {
            "configured": True,
            "defined": key in defined_metrics,
            "value": values.get(key),
            "unit": units.get(key),
            "lastKnown": key in stale_metrics or bool(telemetry_stale and key in values),
        }
        for key in configured_metrics
    }
    ui_status = (
        "nao_configurado"
        if not enabled or status == "not_configured"
        else "online"
        if online
        else "alerta"
        if warning
        else "offline"
    )

    return {
        "id": generator["id"],
        "tag": generator["tag"],
        "name": generator.get("name") or generator["tag"],
        "customer": generator.get("customer") or "",
        "controller": generator.get("controller_model") or generator.get("controller_type") or "",
        "controllerType": generator.get("controller_type") or "",
        "site": generator.get("site") or "",
        "enabled": enabled,
        "status": ui_status,
        "mode": _mode(generator, values),
        "ip": generator.get("host")
        or (f"TCP {generator.get('listen_port')}" if generator.get("listen_port") else "—"),
        "transport": generator.get("transport") or "reverse_tcp",
        "listenPort": generator.get("listen_port"),
        "modbusUnit": generator.get("modbus_unit"),
        "battery": values.get("battery_voltage"),
        "frequency": values.get("frequency"),
        "mainsFrequency": values.get("mains_frequency"),
        "nominalPower": values.get("nominal_power_kw"),
        "rpm": values.get("rpm"),
        "load": values.get("power_kw"),
        "oilPressure": values.get("oil_pressure"),
        "coolantTemp": values.get("coolant_temperature"),
        "fuelLevel": values.get("fuel_level"),
        "alternatorVoltage": values.get("alternator_voltage"),
        "maintenance": values.get("maintenance_hours"),
        "runHours": values.get("run_hours"),
        "latency": None,
        "alarms": int(values.get("alarm_count") or 0)
        if "alarm_count" in values
        else 1
        if values.get("alarm_active")
        else 0,
        "mcb": bool(values.get("mcb_closed", False)),
        "gcb": bool(values.get("gcb_closed", False)),
        "mains": {
            "l1": values.get("mains_voltage_l1"),
            "l2": values.get("mains_voltage_l2"),
            "l3": values.get("mains_voltage_l3"),
            "l12": values.get("mains_voltage_l1_l2"),
        },
        "gen": {
            "l1": values.get("voltage_l1"),
            "l2": values.get("voltage_l2"),
            "l3": values.get("voltage_l3"),
            "l12": values.get("voltage_l1_l2"),
        },
        "metrics": dict(values),
        "availableMetrics": sorted(values.keys()),
        "definedMetrics": defined_metrics,
        "configuredMetrics": configured_metrics,
        "metricStates": metric_states,
        "metricUnits": units,
        "metricLimits": _metric_limits(generator),
        "capabilities": _effective_capabilities(generator, status, binding_present),
        "telemetrySource": "last_known"
        if telemetry_stale
        else "rapid_scada"
        if binding_present and status in {"online", "fault", "connected", "partial"}
        else "none",
        "rapidDeviceNum": generator.get("rapid_device_num"),
        "telemetryStale": bool(telemetry_stale),
        "staleMetrics": stale_metrics,
        "lastTelemetryAt": telemetry_at,
        "dataAgeSeconds": max(0, int(time.time()) - int(telemetry_at)) if telemetry_at else None,
        "lastError": error,
        "health": health or {},
    }


def _overlay_generators(generators):
    bindings = load_bindings()
    bridge_status = _load_bridge_status()
    matched = []
    all_channels = []

    for generator in generators:
        binding = binding_for(generator, bindings)
        matched.append(binding)
        if binding:
            for cfg in (binding.get("channels") or {}).values():
                if "cnl" in cfg:
                    all_channels.append(int(cfg["cnl"]))

    channel_data, read_error = read_channels(all_channels)
    result = []

    for generator, binding in zip(generators, matched):
        configured = sorted((binding.get("channels") or {}).keys()) if binding else []
        health = _transport_health(generator, bridge_status)
        snapshot = db.get_telemetry_snapshot(generator["id"])

        def last_known():
            if not snapshot:
                return {}, [], None
            # Regra operacional: somente combustível, manutenção e horímetro
            # permanecem no card quando a leitura atual deixa de existir.
            allowed = set(configured) & _LAST_KNOWN_CARD_METRICS
            values = {}
            for key, value in snapshot["values"].items():
                if key not in allowed:
                    continue
                try:
                    numeric = float(value)
                    if not math.isfinite(numeric):
                        continue
                    cfg = (binding.get("channels") or {}).get(key) or {}
                    scale = float(cfg.get("scale", 1.0))
                    raw_value = numeric / scale if scale else numeric
                except (TypeError, ValueError, ZeroDivisionError, OverflowError):
                    continue
                if _is_undefined_raw(generator, key, raw_value):
                    continue
                if not _metric_value_in_documented_range(generator, key, numeric):
                    continue
                # Combustível é percentual físico; qualquer last-known fora da
                # faixa é dado inválido, nunca deve reaparecer no card.
                if (
                    str(generator.get("controller_type") or "").strip().upper() == "DSE"
                    and key == "fuel_level"
                    and not 0.0 <= numeric <= 100.0
                ):
                    continue
                values[key] = value
            defined = [key for key in snapshot["defined"] if key in values]
            return values, defined, snapshot["updated_at"]

        if not generator.get("enabled"):
            health.update({"controller": "unknown", "telemetry": "not_configured"})
            result.append(
                _frontend_generator(
                    generator,
                    {},
                    "disabled",
                    defined=[],
                    configured_metrics=configured,
                    binding_present=bool(binding),
                    health=health,
                )
            )
            continue

        if not binding:
            health.update({"controller": "unknown", "telemetry": "not_configured"})
            pack = _pack(generator)
            production_profile = bool(
                pack
                and pack.get("lifecycle") == "production"
                and (pack.get("capabilities") or {}).get("telemetry")
            )
            if production_profile:
                state = "connected" if health.get("transport") == "connected" else "offline"
                detail = "Controladora homologada sem vínculo no motor de telemetria"
            else:
                state = "not_configured"
                detail = "Sem perfil de telemetria de produção homologado"
            result.append(
                _frontend_generator(
                    generator,
                    {},
                    state,
                    detail,
                    defined=[],
                    configured_metrics=[],
                    binding_present=False,
                    health=health,
                )
            )
            continue

        values = {}
        invalid_values = []
        for key, cfg in (binding.get("channels") or {}).items():
            item = channel_data.get(int(cfg["cnl"]))
            if not item or not item.get("defined"):
                continue
            raw_value = item.get("val")
            if _is_undefined_raw(generator, key, raw_value):
                continue
            try:
                scale = float(cfg.get("scale", 1.0))
                value = float(raw_value) * scale
            except (TypeError, ValueError, OverflowError):
                invalid_values.append(key)
                continue
            if not math.isfinite(value):
                invalid_values.append(key)
                continue
            if not _metric_value_in_documented_range(generator, key, value):
                invalid_values.append(key)
                continue
            # PF físico é adimensional e deve permanecer no intervalo [-1, 1].
            # Qualquer valor fora disso é erro de mapa/escala ou sentinela.
            if key == "power_factor" and not -1.001 <= value <= 1.001:
                invalid_values.append(key)
                continue
            values[key] = (
                int(round(value))
                if abs(value - round(value)) < 1e-9
                and key not in {"frequency", "mains_frequency", "bus_frequency"}
                else round(value, 3)
            )

        derived = [*_derive_breaker_feedback(values), *_derive_dse_status(generator, values)]
        if derived:
            configured = sorted(set([*configured, *derived]))
        defined = sorted(values.keys())

        if read_error:
            health.update({"controller": "unknown", "telemetry": "error"})
            state = "offline" if health.get("transport") == "disconnected" else "fault"
            stale_values, _stale_defined, stale_at = last_known()
            result.append(
                _frontend_generator(
                    generator,
                    stale_values,
                    state,
                    read_error,
                    defined=[],
                    configured_metrics=configured,
                    binding_present=True,
                    health=health,
                    telemetry_at=stale_at,
                    telemetry_stale=bool(stale_values),
                )
            )
        elif values:
            previous_values, _previous_defined, _previous_at = last_known()
            display_values = {**previous_values, **values}
            stale_metrics = sorted(set(display_values) - set(defined))
            try:
                # Snapshot do card = leitura atual + somente last-known válidos.
                # Não persiste lixo histórico que deixou de ser definido.
                snapshot_values = dict(display_values)
                snapshot_defined = sorted(snapshot_values.keys())
                db.save_telemetry_snapshot(
                    generator["id"], snapshot_values, snapshot_defined
                )
            except sqlite3.Error as exc:
                print(f"[rapid] falha ao persistir snapshot de {generator['id']}: {exc}", flush=True)
            telemetry_at = int(time.time())
            controller_ok = _has_controller_health(values, configured)
            health.update(
                {
                    "controller": "responding" if controller_ok else "partial",
                    "telemetry": "fresh" if controller_ok and not invalid_values else "partial",
                }
            )
            detail_parts = []
            if not controller_ok:
                detail_parts.append("Telemetria parcial sem métrica de saúde da controladora")
            if invalid_values:
                detail_parts.append(
                    "Canais Rapid com valor inválido: " + ", ".join(sorted(invalid_values))
                )
            alarm_active = bool(values.get("alarm_active"))
            result.append(
                _frontend_generator(
                    generator,
                    display_values,
                    "fault" if alarm_active else "online" if controller_ok else "partial",
                    "; ".join(detail_parts),
                    defined=defined,
                    configured_metrics=configured,
                    binding_present=True,
                    health=health,
                    telemetry_at=telemetry_at,
                    stale_metrics=stale_metrics,
                )
            )
        elif invalid_values:
            health.update({"controller": "unknown", "telemetry": "invalid"})
            stale_values, _stale_defined, stale_at = last_known()
            result.append(
                _frontend_generator(
                    generator,
                    stale_values,
                    "fault",
                    "Motor de telemetria retornou apenas valores inválidos: "
                    + ", ".join(sorted(invalid_values)),
                    defined=[],
                    configured_metrics=configured,
                    binding_present=True,
                    health=health,
                    telemetry_at=stale_at,
                    telemetry_stale=bool(stale_values),
                )
            )
        else:
            health.update({"controller": "unknown", "telemetry": "no_data"})
            state = (
                "connected" if health.get("transport") == "connected" else "offline"
            )
            stale_values, _stale_defined, stale_at = last_known()
            result.append(
                _frontend_generator(
                    generator,
                    stale_values,
                    state,
                    "Motor de telemetria sem dados definidos para esta controladora",
                    defined=[],
                    configured_metrics=configured,
                    binding_present=True,
                    health=health,
                    telemetry_at=stale_at,
                    telemetry_stale=bool(stale_values),
                )
            )

    return result


def overlay_generators(generators):
    """Combina inventário persistido com telemetria sem permitir que a telemetria apague o parque."""
    generators = list(generators)
    try:
        return _overlay_generators(generators)
    except Exception as exc:
        print(f"[rapid] falha ao compor overlay: {type(exc).__name__}: {exc}", flush=True)
        detail = f"Telemetria Rapid indisponível ({type(exc).__name__})"
        return [
            _frontend_generator(
                generator,
                {},
                "offline",
                detail,
                defined=[],
                configured_metrics=[],
                binding_present=False,
                health={
                    "transport": "unknown",
                    "controller": "unknown",
                    "telemetry": "error",
                },
            )
            for generator in generators
        ]


def _current_metric_keys(generator: dict) -> set[str]:
    if generator.get("telemetryStale"):
        return set()
    metrics = generator.get("definedMetrics")
    if metrics is None:
        metrics = generator.get("availableMetrics") or []
    return set(metrics)


def dashboard(generators):
    return {
        "total": len(generators),
        "online": sum(g["status"] == "online" for g in generators),
        "alerts": sum(g["status"] == "alerta" for g in generators),
        "offline": sum(g["status"] == "offline" for g in generators),
        "notConfigured": sum(g["status"] == "nao_configurado" for g in generators),
        "running": sum(
            "rpm" in _current_metric_keys(g)
            and g.get("rpm") is not None
            and float(g.get("rpm")) > 0
            for g in generators
        ),
        "loadKw": round(
            sum(
                float(g.get("load") or 0)
                for g in generators
                if "power_kw" in _current_metric_keys(g) and g.get("load") is not None
            ),
            3,
        ),
    }
