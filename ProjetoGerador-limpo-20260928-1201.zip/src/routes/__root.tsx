import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import {
  Outlet,
  Link,
  Navigate,
  createRootRouteWithContext,
  useRouter,
  useRouterState,
  HeadContent,
  Scripts,
} from "@tanstack/react-router";
import { type ReactNode } from "react";

import appCss from "../styles.css?url";
import { AppSidebar } from "@/components/layout/AppSidebar";
import { LayoutProvider } from "@/components/layout/LayoutContext";
import { ThemeProvider, themeInitScript } from "@/components/layout/ThemeProvider";
import { AuthProvider, useAuth } from "@/components/auth/AuthProvider";
import { GeneratorsProvider, useGenerators } from "@/components/generators/GeneratorsProvider";
import { ScadaOpsProvider, useScadaOps } from "@/components/scada/ScadaOpsProvider";

function NotFoundComponent() {
  return (
    <div className="flex min-h-screen items-center justify-center bg-background px-4">
      <div className="max-w-md text-center">
        <h1 className="text-7xl font-bold text-foreground">404</h1>
        <h2 className="mt-4 text-xl font-semibold text-foreground">Página não encontrada</h2>
        <p className="mt-2 text-sm text-muted-foreground">
          A página solicitada não existe ou foi movida.
        </p>
        <div className="mt-6">
          <Link
            to="/"
            className="inline-flex items-center justify-center rounded-md bg-primary px-4 py-2 text-sm font-medium text-primary-foreground transition-colors hover:bg-primary/90"
          >
            Voltar ao início
          </Link>
        </div>
      </div>
    </div>
  );
}

function ErrorComponent({ error, reset }: { error: Error; reset: () => void }) {
  console.error(error);
  const router = useRouter();
  return (
    <div className="flex min-h-screen items-center justify-center bg-background px-4">
      <div className="max-w-md text-center">
        <h1 className="text-xl font-semibold tracking-tight text-foreground">
          Esta página não carregou
        </h1>
        <p className="mt-2 text-sm text-muted-foreground">
          O sistema encontrou uma falha ao carregar esta tela. Tente novamente ou volte ao início.
        </p>
        <div className="mt-6 flex flex-wrap justify-center gap-2">
          <button
            onClick={() => {
              router.invalidate();
              reset();
            }}
            className="inline-flex items-center justify-center rounded-md bg-primary px-4 py-2 text-sm font-medium text-primary-foreground transition-colors hover:bg-primary/90"
          >
            Tentar novamente
          </button>
          <a
            href="/"
            className="inline-flex items-center justify-center rounded-md border border-input bg-background px-4 py-2 text-sm font-medium text-foreground transition-colors hover:bg-accent"
          >
            Voltar ao início
          </a>
        </div>
      </div>
    </div>
  );
}

export const Route = createRootRouteWithContext<{ queryClient: QueryClient }>()({
  head: () => ({
    meta: [
      { charSet: "utf-8" },
      { name: "viewport", content: "width=device-width, initial-scale=1, viewport-fit=cover" },
      { title: "RC Geradores" },
      {
        name: "description",
        content: "Sistema profissional de monitoramento e operação de geradores.",
      },
      { name: "author", content: "RC Geradores" },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
    links: [
      { rel: "stylesheet", href: appCss },
      { rel: "icon", href: "/favicon.ico", type: "image/x-icon" },
    ],
  }),
  shellComponent: RootShell,
  component: RootComponent,
  notFoundComponent: NotFoundComponent,
  errorComponent: ErrorComponent,
});

function RootShell({ children }: { children: ReactNode }) {
  return (
    <html lang="pt-BR" suppressHydrationWarning>
      <head>
        <script dangerouslySetInnerHTML={{ __html: themeInitScript }} />
        <HeadContent />
      </head>
      <body>
        {children}
        <Scripts />
      </body>
    </html>
  );
}

function RootComponent() {
  const { queryClient } = Route.useRouteContext();

  return (
    <QueryClientProvider client={queryClient}>
      <ThemeProvider>
        <LayoutProvider>
          <AuthProvider>
            <AppShell />
          </AuthProvider>
        </LayoutProvider>
      </ThemeProvider>
    </QueryClientProvider>
  );
}

function AppShell() {
  const { user, ready } = useAuth();
  const pathname = useRouterState({ select: (s) => s.location.pathname });

  if (pathname === "/reset-password") {
    return <Outlet />;
  }

  if (pathname === "/login") {
    if (ready && user) return <Navigate to="/" />;
    return <Outlet />;
  }

  if (!ready) {
    return (
      <div className="grid min-h-dvh place-items-center bg-background text-sm text-muted-foreground">
        Carregando…
      </div>
    );
  }

  if (!user) return <Navigate to="/login" />;

  return (
    <GeneratorsProvider>
      <ScadaOpsProvider>
        <AuthenticatedShell />
      </ScadaOpsProvider>
    </GeneratorsProvider>
  );
}

function AuthenticatedShell() {
  const { usersError, refreshUsers, can } = useAuth();
  const { error: generatorsError, refresh: refreshGenerators } = useGenerators();
  const { error: opsError, refresh: refreshOps } = useScadaOps();
  const hasError = Boolean(generatorsError || opsError || usersError);

  return (
    <div className="rc-app-shell flex h-dvh w-full overflow-hidden">
      <AppSidebar />
      <main className="flex h-dvh min-w-0 flex-1 flex-col overflow-hidden">
        {hasError && (
          <div className="rc-system-banner z-50 flex flex-wrap items-center justify-between gap-2 border-b border-offline/40 bg-offline/10 px-3 py-2 text-[12px] text-offline">
            <div className="min-w-0">
              <b>Falha ao carregar dados do sistema.</b>
              {generatorsError && <span className="ml-1">Geradores: {generatorsError}.</span>}
              {opsError && <span className="ml-1">Operação: {opsError}.</span>}
              {usersError && <span className="ml-1">Usuários: {usersError}.</span>}
            </div>
            <button
              type="button"
              onClick={() => {
                void refreshGenerators();
                void refreshOps();
                if (can("manageUsers")) void refreshUsers().catch(() => undefined);
              }}
              className="h-7 shrink-0 rounded-md border border-offline/40 px-2 font-semibold"
            >
              Tentar novamente
            </button>
          </div>
        )}
        <Outlet />
      </main>
    </div>
  );
}
