import { useCallback, useEffect, useMemo, useState } from "react";

import { useGenerators } from "@/components/generators/GeneratorsProvider";
import { metricNumber } from "@/components/generators/generator-metrics";
import { industrialApi, type IndustrialAlarm, type MaintenancePlan } from "@/lib/industrial-api";
import { rcApi, type SystemDiagnostics } from "@/lib/api";
import { useScadaOps } from "./ScadaOpsProvider";

export type TrafficPort = {
  remotePort: number;
  todayRx: number;
  todayTx: number;
  todayBytes: number;
  monthRx: number;
  monthTx: number;
  monthBytes: number;
};

export type TrafficSummary = {
  day: string;
  month: string;
  todayRx: number;
  todayTx: number;
  todayBytes: number;
  monthRx: number;
  monthTx: number;
  monthBytes: number;
  todaySeries?: number[];
  monthSeries?: number[];
  todayQuota?: number | null;
  monthQuota?: number | null;
  ports: TrafficPort[];
  updatedAt: number;
};

type ProductDiagnostics = SystemDiagnostics & {
  bridge: SystemDiagnostics["bridge"] & { traffic?: TrafficSummary };
};

export type GeneratorStatusSummary = {
  online: number;
  alert: number;
  offline: number;
  unconfigured: number;
};

export type SiteDecisionRow = {
  site: string;
  total: number;
  online: number;
  alert: number;
  offline: number;
};

export type LowFuelRow = {
  tag: string;
  site: string;
  value: number;
};

export type FuelSummary = {
  count: number;
  totalGenerators: number;
  average: number | null;
  min: number | null;
  max: number | null;
  unit: string | null;
  mixedUnits: boolean;
};

export type ModemDecisionRow = {
  remotePort: number;
  label: string;
  connected: boolean;
  today: number;
  month: number;
};

export type WorkSummary = {
  open: number;
  urgent: number;
  running: number;
  planned: number;
  error: boolean;
};

export type MaintenanceSummary = {
  due: number;
  warning: number;
  ok: number;
  error: string | null;
};

export type SeverityBucket = {
  label: string;
  value: number;
  tone: "critical" | "alarm" | "warning" | "info";
};

export function formatBytes(value: number | null | undefined) {
  const bytes = Math.max(0, Number(value || 0));
  if (bytes < 1024) return `${bytes.toFixed(0)} B`;
  if (bytes < 1024 ** 2) return `${(bytes / 1024).toFixed(1)} KB`;
  if (bytes < 1024 ** 3) return `${(bytes / 1024 ** 2).toFixed(1)} MB`;
  return `${(bytes / 1024 ** 3).toFixed(2)} GB`;
}

export function pct(value: number, total: number) {
  if (total <= 0) return 0;
  return Math.min(100, Math.max(0, (value / total) * 100));
}

export function alarmTone(severity: string) {
  if (severity === "fault") return "err" as const;
  if (severity === "alarm" || severity === "warning") return "warn" as const;
  return "info" as const;
}

export function alarmLabel(severity: string) {
  if (severity === "fault") return "Crítico";
  if (severity === "alarm") return "Alto";
  if (severity === "warning") return "Médio";
  return "Baixo";
}

export function friendlyAlarmMessage(alarm: IndustrialAlarm) {
  if (alarm.code === "COMM_LOSS") return "Falha de comunicação com equipamento em campo.";
  if (/rapid|scada|binding|modbus|device|controller pack|canal/i.test(alarm.message)) {
    return "Ocorrência de comunicação requer verificação.";
  }
  return alarm.message || "Ocorrência ativa requer verificação.";
}

function metricUnit(
  generator: { metricUnits?: Record<string, string> },
  key: string,
  fallback = "",
) {
  return generator.metricUnits?.[key] || fallback;
}

function isOpenWorkOrder(status: string) {
  return !/conclu|cancel|fechad/i.test(status);
}

export function useOverviewDecisionModel() {
  const {
    generators,
    ready: generatorsReady,
    error: generatorsError,
    refresh: refreshGenerators,
  } = useGenerators();
  const { workOrders, error: opsError, refresh: refreshOps } = useScadaOps();
  const [diag, setDiag] = useState<ProductDiagnostics | null>(null);
  const [alarms, setAlarms] = useState<IndustrialAlarm[]>([]);
  const [maintenance, setMaintenance] = useState<MaintenancePlan[]>([]);
  const [diagError, setDiagError] = useState<string | null>(null);
  const [alarmError, setAlarmError] = useState<string | null>(null);
  const [maintenanceError, setMaintenanceError] = useState<string | null>(null);
  const [updatedAt, setUpdatedAt] = useState<Date | null>(null);

  const refreshOperational = useCallback(async () => {
    const [healthResult, alarmResult, maintenanceResult] = await Promise.allSettled([
      rcApi.system.health(),
      industrialApi.alarms.list(true),
      industrialApi.maintenance.list(),
    ]);

    if (healthResult.status === "fulfilled") {
      setDiag(healthResult.value as ProductDiagnostics);
      setDiagError(null);
    } else {
      setDiagError(
        healthResult.reason instanceof Error
          ? healthResult.reason.message
          : "Falha ao consultar comunicação.",
      );
    }

    if (alarmResult.status === "fulfilled") {
      setAlarms(alarmResult.value);
      setAlarmError(null);
    } else {
      setAlarmError(
        alarmResult.reason instanceof Error
          ? alarmResult.reason.message
          : "Falha ao consultar alarmes.",
      );
    }

    if (maintenanceResult.status === "fulfilled") {
      setMaintenance(maintenanceResult.value);
      setMaintenanceError(null);
    } else {
      setMaintenanceError(
        maintenanceResult.reason instanceof Error
          ? maintenanceResult.reason.message
          : "Falha ao consultar manutenção.",
      );
    }
    setUpdatedAt(new Date());
  }, []);

  useEffect(() => {
    void refreshOperational();
    const timer = window.setInterval(() => void refreshOperational(), 10000);
    return () => window.clearInterval(timer);
  }, [refreshOperational]);

  const fleet = generators;

  const activeAlarms = useMemo(
    () =>
      [...alarms]
        .filter((alarm) => alarm.active)
        .sort((a, b) => Number(b.last_seen || 0) - Number(a.last_seen || 0)),
    [alarms],
  );

  const generatorStatus = useMemo<GeneratorStatusSummary>(
    () => ({
      online: fleet.filter((generator) => generator.status === "online").length,
      alert: fleet.filter((generator) => generator.status === "alerta").length,
      offline: fleet.filter((generator) => generator.status === "offline").length,
      unconfigured: fleet.filter((generator) => generator.status === "nao_configurado").length,
    }),
    [fleet],
  );

  const fuel = useMemo<FuelSummary>(() => {
    const measured = fleet
      .map((generator) => {
        const value = metricNumber(generator, "fuel_level", generator.fuelLevel);
        const unit = metricUnit(generator, "fuel_level", "");
        return value == null || !unit ? null : { value, unit };
      })
      .filter((row): row is { value: number; unit: string } => row != null);
    const units = new Set(measured.map((row) => row.unit));
    const mixedUnits = units.size > 1;
    const unit = units.size === 1 ? ([...units][0] ?? null) : null;
    const readings =
      unit == null ? [] : measured.filter((row) => row.unit === unit).map((row) => row.value);
    return {
      count: measured.length,
      totalGenerators: fleet.length,
      average:
        readings.length && !mixedUnits
          ? readings.reduce((sum, value) => sum + value, 0) / readings.length
          : null,
      min: readings.length && !mixedUnits ? Math.min(...readings) : null,
      max: readings.length && !mixedUnits ? Math.max(...readings) : null,
      unit,
      mixedUnits,
    };
  }, [fleet]);

  const bridgeFresh = diag?.bridge.statusFresh === true;
  const sessions = useMemo(
    () => [...(diag?.bridge.sessions ?? [])].sort((a, b) => a.remotePort - b.remotePort),
    [diag],
  );
  const connectedModems = bridgeFresh ? sessions.filter((session) => session.connected).length : 0;
  const traffic = diag?.bridge.traffic;
  const trafficByPort = useMemo(
    () => new Map((traffic?.ports ?? []).map((item) => [item.remotePort, item])),
    [traffic],
  );
  const modemRows = useMemo<ModemDecisionRow[]>(
    () =>
      sessions.map((session, index) => {
        const usage = trafficByPort.get(session.remotePort);
        return {
          remotePort: session.remotePort,
          label: `Modem ${String(index + 1).padStart(2, "0")}`,
          connected: session.connected,
          today: usage?.todayBytes ?? 0,
          month: usage?.monthBytes ?? 0,
        };
      }),
    [sessions, trafficByPort],
  );
  const maxMonthTraffic = Math.max(1, ...modemRows.map((item) => item.month));

  const openWorkOrders = useMemo(
    () => workOrders.filter((workOrder) => isOpenWorkOrder(workOrder.status)),
    [workOrders],
  );
  const work: WorkSummary = {
    open: openWorkOrders.length,
    urgent: openWorkOrders.filter((item) => /urgente/i.test(item.status)).length,
    running: openWorkOrders.filter((item) => /andamento/i.test(item.status)).length,
    planned: openWorkOrders.filter((item) => /planejada/i.test(item.status)).length,
    error: Boolean(opsError),
  };

  const maintenanceSummary: MaintenanceSummary = {
    due: maintenance.filter((item) => item.enabled && item.state === "due").length,
    warning: maintenance.filter((item) => item.enabled && item.state === "warning").length,
    ok: maintenance.filter((item) => item.enabled && item.state === "ok").length,
    error: maintenanceError,
  };

  const severity: SeverityBucket[] = [
    {
      label: "Crítico",
      value: activeAlarms.filter((item) => item.severity === "fault").length,
      tone: "critical",
    },
    {
      label: "Alto",
      value: activeAlarms.filter((item) => item.severity === "alarm").length,
      tone: "alarm",
    },
    {
      label: "Médio",
      value: activeAlarms.filter((item) => item.severity === "warning").length,
      tone: "warning",
    },
    {
      label: "Baixo",
      value: activeAlarms.filter((item) => !["fault", "alarm", "warning"].includes(item.severity))
        .length,
      tone: "info",
    },
  ];
  const severityMax = Math.max(1, ...severity.map((item) => item.value));

  const sites = useMemo<SiteDecisionRow[]>(() => {
    const grouped = new Map<string, SiteDecisionRow>();
    for (const generator of fleet) {
      const current = grouped.get(generator.site) ?? {
        site: generator.site,
        total: 0,
        online: 0,
        alert: 0,
        offline: 0,
      };
      current.total += 1;
      if (generator.status === "online") current.online += 1;
      if (generator.status === "alerta") current.alert += 1;
      if (generator.status === "offline") current.offline += 1;
      grouped.set(generator.site, current);
    }
    return [...grouped.values()].sort((a, b) => b.total - a.total || a.site.localeCompare(b.site));
  }, [fleet]);

  const lowFuel = useMemo<LowFuelRow[]>(
    () =>
      fleet
        .map((generator) => {
          const value = metricNumber(generator, "fuel_level", generator.fuelLevel);
          return value == null ? null : { tag: generator.tag, site: generator.site, value };
        })
        .filter((row): row is LowFuelRow => row != null)
        .sort((a, b) => a.value - b.value)
        .slice(0, 6),
    [fleet],
  );

  const siteByGenerator = useMemo(
    () => Object.fromEntries(fleet.map((generator) => [generator.id, generator.site])),
    [fleet],
  );

  const sitesWithAttention = useMemo(() => {
    const generatorSite = new Map(fleet.map((generator) => [generator.id, generator.site]));
    return new Set(
      activeAlarms
        .map((alarm) => (alarm.generator_id ? generatorSite.get(alarm.generator_id) : undefined))
        .filter((site): site is string => Boolean(site)),
    ).size;
  }, [activeAlarms, fleet]);

  const retryAll = () => {
    void refreshGenerators();
    void refreshOps();
    void refreshOperational();
  };

  return {
    demo: false,
    updatedAt,
    retryAll,
    hasAnyError: Boolean(generatorsError || diagError || alarmError || maintenanceError || opsError),
    generatorsReady,
    generatorsError,
    totalGenerators: fleet.length,
    generatorStatus,
    fuel,
    bridgeFresh,
    modemCount: sessions.length,
    connectedModems,
    traffic,
    modemRows,
    maxMonthTraffic,
    communicationLoading: !diag && !diagError,
    activeAlarms,
    alarmError,
    sites,
    lowFuel,
    siteByGenerator,
    sitesWithAttention,
    work,
    maintenance: maintenanceSummary,
    severity,
    severityMax,
  };
}
